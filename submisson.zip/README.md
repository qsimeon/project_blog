# project_blog
Blog for MIT Deep Learning (6.7960) final project by Gabe Manso &amp; Quilee Simeon.

Link to Google Colab notebook: [![Open In Colab](https://colab.research.google.com/assets/colab-badge.svg)](https://colab.research.google.com/drive/1tguG-THn52pPGcU9KIkmVBzYbhiPfw1w?usp=sharing)

Link to Weights & Biases logs: [![Weights & Biases](https://img.shields.io/badge/W%26B-Explore-orange?logo=weightsandbiases)]([https://wandb.ai/your_username/your_project](https://wandb.ai/gmanso-mit/multimodal-proj))

